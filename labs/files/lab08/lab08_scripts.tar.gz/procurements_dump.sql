CREATE TABLE ministries (
id SERIAL PRIMARY KEY,
name VARCHAR(130),
employee_count INT
);

CREATE TABLE procurements (
id SERIAL PRIMARY KEY,
published_at DATE,
title VARCHAR(255),
supplier VARCHAR(255),
price FLOAT,
ministry_id BIGINT REFERENCES ministries(id)
);

INSERT INTO ministries(name, employee_count) VALUES
('Ministerstvo vnútra', 120),
('Ministerstvo kultúry', 60),
('Ministerstvo poľnohospodárstva', 80),
('Ministerstvo školstva', 100),
('Ministerstvo životného prostredia', 110);

INSERT INTO procurements(published_at, title, supplier, price, ministry_id) VALUES
('2016-01-01', 'Realblab', 'Feedspan',200000,1),
('2016-01-15', 'Zazio', 'Yozio',180000,2),
('2016-01-31', 'Livefish', 'Tagpad',160000,3),
('2016-02-01', 'BlogXS','Dynabox',150000,4),
('2016-02-15', 'Jabbertype','Zoomdog',170000,5),
('2016-02-28', 'Edgelab','Demimbu',300000,1),
('2016-03-01', 'Meem','Yakitri',120000,2);
