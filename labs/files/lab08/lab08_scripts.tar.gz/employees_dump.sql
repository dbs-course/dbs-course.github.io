CREATE TABLE employees (
	id serial PRIMARY KEY,
	name varchar(50),
	salary bigint,
	department_id bigint
);

CREATE TABLE departments (
id serial PRIMARY KEY,
name varchar(30)
);

INSERT INTO departments(name) VALUES
('IT'),
('Sales'),
('Marketing');

INSERT INTO employees(name, salary, department_id) values 
('Jimmy Gonzalez', 782,1),
('Peter Anderson', 750,1),
('Justin Bennett', 728,1),
('Brandon Little', 728,1),
('Donna Andrews', 715,1),
('Jerry Harper', 612,2),
('Judy Fox', 707,2),
('Paula Murphy', 759,2),
('Rachel Murphy', 719,2),
('Joshua Smith', 750, 3),
('Nancy Mason', 783, 3);
